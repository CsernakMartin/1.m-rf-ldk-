package com.example.projektmunka;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class UserProfileActivity extends AppCompatActivity {

    TextView textViewWelcome;
    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);

        textViewWelcome = findViewById(R.id.textViewWelcome);

        // Példa: email-t lekérni intentből
        Intent intent = getIntent();
        String email = intent.getStringExtra("email");

        textViewWelcome.setText("Üdv, " + email + "!");


        // Toolbar inicializálása
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        // DrawerLayout és NavigationView
        drawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        // LayoutInflater használata az imageview hozzáadásához
        LayoutInflater inflater = LayoutInflater.from(this);
        View customView = inflater.inflate(R.layout.toolbar_image, null);  // A kép hozzáadása
        Toolbar.LayoutParams layoutParams = new Toolbar.LayoutParams(
                Toolbar.LayoutParams.WRAP_CONTENT,
                Toolbar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);  // A középre igazítás

        // A customView hozzáadása a Toolbar-hoz
        toolbar.addView(customView, layoutParams);

        // ActionBarDrawerToggle beállítása
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        toggle.getDrawerArrowDrawable().setColor(Color.parseColor("#1da1f2"));
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Menüelemek betöltése
        navigationView.inflateMenu(R.menu.userprofile_menu);

        // Menüelem kiválasztás kezelése
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.nav_home) {
                    Intent intent = new Intent(UserProfileActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                if (id == R.id.nav_settings) {
                    Intent intent = new Intent(UserProfileActivity.this, SettingsActivity.class);
                    startActivity(intent);
                }
                if (id == R.id.nav_profile) {
                    Intent intent = new Intent(UserProfileActivity.this, UserProfileActivity.class);
                    startActivity(intent);
                }
                drawerLayout.closeDrawer(GravityCompat.START);
                return true;
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    public void Logout(View view) {
        // SharedPreferences reset
        SharedPreferences sharedPreferences = getSharedPreferences("MyAppPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.apply();

        // Ugrás vissza a login screenre (ProfileActivity)
        Intent intent = new Intent(UserProfileActivity.this, ProfileActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // hogy ne lehessen visszalépni
        startActivity(intent);
        finish(); // bezárja a UserProfileActivity-t
    }
}

